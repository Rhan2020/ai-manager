declare module 'remark-gfm' {
  const remarkGfm: any;
  export default remarkGfm;
}